package com.example.finalproject.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
class Person(@PrimaryKey val id:Long) {


}
